#ifndef HASHMAP_H
    #define HASHMAP_H
    
    #include <stdio.h>
    #include <string.h>
    #include <stdlib.h>
    #include <time.h>
    #include <stdbool.h>
    #include "abr.h"


    typedef struct HM {
        int size;
        struct Tree *pRoot;
    } HM;

    HM *createHashMap();
    int hachage(char *chaine);
    int addHM(HM *map, char *key, int value);
    int *getHM(HM *map, char *key);
    int removeHM(HM *map, char *key);
    int sizeHM(HM *map);
    int updateHM(HM *map, char *key, int newValue);
    void display(HM *map);
    void freeHashMap(HM *map);



#endif
