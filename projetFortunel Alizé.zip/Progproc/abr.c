#include "abr.h"



/**
 * @brief Creates a new tree node.
 * This function creates a new tree node. It dynamically allocates
 * memory for the node, initializes its hash, pleft and pright fields, and calls
 * the createChainon function to create a linked list node and associate it with
 * the tree node.
 *
 * @param key Key to be added.
 * @param hash Hash value corresponding to the key.
 * @param value Value associated with the key.
 * @return A pointer to the new tree node.
 */

Tree *createTree(int a, char *k, int v) {
  Tree *n = (Tree *)malloc(sizeof(Tree));
  if (n == NULL) {
    printf("Memory allocation failed for Tree\n");
    exit(EXIT_FAILURE);
  }
  n->hash = a;
  n->pleft = NULL;
  n->pright = NULL;
  n->cell = createChainon(k, v);
  return n;
}


/**
 * @brief Adds a node to the tree.
 *
 * This function adds a node to the tree. If the tree is empty (*head ==
 * NULL), it creates a new node with createTree and places it as the root of the
 * tree. If a node with the same hash already exists, it is replaced by a new node.
 * If the hash is smaller, the function is called recursively on the right subtree,
 * otherwise on the left subtree.
 *
 * @param head Pointer to the root of the tree.
 * @param key Key to be added.
 * @param hash Hash value corresponding to the key.
 * @param value Value associated with the key.
 * @param result Pointer to a pointer where the result will be stored.
 */

int addArbre(Tree **head, char *key, int hash, int value) {
  if (*head == NULL || key == NULL) {
    *head = createTree(hash, key, value);
    return 1;
  }

  if ((*head)->hash == hash) {
    // Keys with the same hash value are added to the linked list
    Node *newNode = createChainon(key, value);
    newNode->pNext = (*head)->cell;
    (*head)->cell = newNode;
    return 1;
  }

  if ((*head)->hash < hash) {
    addArbre(&(*head)->pright, key, hash, value);
    return 1;
  }

  if ((*head)->hash > hash) {
    addArbre(&(*head)->pleft, key, hash, value);
    return 1;
  }
  return 0; // Return 0 if the function reaches this point (to handle other cases)
}



/**
 * @brief Searches for a key in the tree.
 *
 * This function searches for a key in the tree. It takes the root of
 * the tree (head), the key (key), the hash of the key (hash), and a pointer to the
 * result (result). The function recursively traverses the tree, searches for the
 * key in the chained list associated with the node and updates the result pointer
 * if the key is found.
 *
 * @param head Pointer to the root of the tree.
 * @param key The key to search for.
 * @param hash Hash value corresponding to the key.
 * @param result Pointer to a pointer where the result will be stored.
 */

int searchTree(Tree *head, char *key, int hash, int **result){
  // If the tree is empty, print a message and return 0
  if (head == NULL || key == NULL) {
    printf("Key not find");
    return 0;
  }
  // If the hash matches, search the linked list for the key
  if (head->hash == hash) {
    Node *current = head->cell;
    while (current != NULL) {
      // If the key is found, update the result pointer and return 1
      if (strcmp(current->key, key) == 0) {
        *result = &(current->value);
        return true;
      }
      current = current->pNext;
    }
    /// If the hash is smaller, recursively call searchTree on the right subtree
  } else if (head->hash < hash) {
    return searchTree(head->pright, key, hash, result);
    // If the hash is larger, recursively call searchTree on the left subtree
  } else {
    return searchTree(head->pleft, key, hash, result);
  }
  printf("Key not find");
  return false;
}



/**
 * @brief Deletes the node with the maximum value from a subtree.
 *
 * This function deletes the node with the maximum value from a subtree.
 * It takes the node to be deleted (node) and a pointer to the target node
 * (pTarget). If the node to be deleted is found, its value and associated linked
 * list are copied to the target node, then the original node is deleted.
 *
 * @param node The node to be deleted.
 * @param pTarget Pointer to the target node.
 */

Tree *suppMax(Tree *node, Tree *pTarget) {
  if (node == NULL) {
    return NULL;
  }
  if (node->pright == NULL) {
    Tree *temp = node->pleft;
    // update target
    pTarget->hash = node->hash;
    pTarget->cell = node->cell;
    // free
    free(node);
    return temp;
  }
  node->pright = suppMax(node->pright, pTarget);
  return node;
}




/**
 * @brief Removes a node with a given key from the tree.
 *
 * This function removes a node with a given key from the tree. If the
 * node to be removed is found, its key and associated linked list are removed. If
 * the node has a left subtree, the suppMax function is used to find and delete the
 * node with the maximum value of the left subtree. Otherwise, the node is replaced
 * by the right subtree.
 *
 * @param head Pointer to the root of the tree.
 * @param key The key to be removed.
 */

int removeTree(Tree **head, char *key, int hash) {
  if (*head == NULL || key == NULL) {
    return 0; // Key not find
  }

  if ((*head)->hash == hash) {
    Node *current = (*head)->cell;
    Node *prev = NULL;

    // Search for the key in the node's linked list
    while (current != NULL && strcmp(current->key, key) != 0) {
      prev = current;
      current = current->pNext;
    }

    // If the key is found in the linked list, delete it
    if (current != NULL) {
      if (prev != NULL) {
        prev->pNext = current->pNext;
      } else {
        // If the key is the first in the linked list, adjust the head
        (*head)->cell = current->pNext;
      }

      free(current->key);
      free(current);

      // If the linked list is empty, delete the node from the tree
      if ((*head)->cell == NULL) {
        if ((*head)->pleft) {
          (*head)->pleft = suppMax((*head)->pleft, *head);
        } else {
          Tree *tmp = *head;
          *head = (*head)->pright;
          free(tmp);
        }
      }
      return 1; // success
    }
  } else if ((*head)->hash < hash) {
    return removeTree(&(*head)->pright, key, hash);
  } else {
    return removeTree(&(*head)->pleft, key, hash);
  }

  return 0; // key not find
}



/**
 * @brief Performs a prefixpath of an ABR.
 *
 * This function performs a prefixpath of an ABR. It takes the
 * root of the tree as a parameter, displays the value of the current node,
 * recursively calls the function for the left subtree, then recursively calls the
 * function for the right subtree.
 *
 * @param root The root of the tree.
 */

void parcoursPrefixe(Tree *arb) {
 if (arb != NULL) {
    afficherListeRec(arb->cell);
    printf("%d \n", arb->hash);
    parcoursPrefixe(arb->pleft);
    parcoursPrefixe(arb->pright);
  }
}



/**
 * @brief Frees the memory allocated for the tree.
 *
 * This function frees the memory allocated for the tree. It uses a
 * recursive function to free the nodes of the tree and the nodes of the associated
 * linked list.
 *
 * @param head Pointer to the root of the tree.
 */

void freeTree(Tree *node) {
  if (node != NULL) {
    freeTree(node->pleft);
    freeTree(node->pright);
    Node *current = node->cell;
    while (current != NULL) {
      Node *temp = current;
      current = current->pNext;
      free(temp->key);
      free(temp);
    }
    free(node);
  }
}



	
