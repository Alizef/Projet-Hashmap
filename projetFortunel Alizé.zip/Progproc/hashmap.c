#include "hashmap.h"


/**
 * @brief Allocates memory for a new HM structure HashMap.
 *
 * This function allocates memory for a new HM structure HashMap.
 * If the allocation fails, it prints an error message and exits the program.
 * It initializes the size of the HashMap to 0 and the pointer to the root of
 * the tree to NULL. It returns a pointer to the new HashMap.
 *
 * @return A pointer to the new HashMap.
 */

HM *createHashMap() {
  HM *map = (HM *)malloc(sizeof(HM));
  if (map == NULL) {
    printf("Memory allocation failed for HashMap\n");
    exit(EXIT_FAILURE);
  }
  map->size = 0;
  map->pRoot = NULL;
  return map;
}



/**
 * @brief Calculates a hash index for a given character string.
 *
 * This function takes a character string as input and calculates a hash index.
 * It returns the resulting hash index.
 *
 * @param str The input character string.
 * @return The hash index.
 */

int hachage(char *chaine) {
  if(chaine == NULL){
    return 0;
  }
  int i = 0, nbHache = 0;
  for (i = 0; chaine[i] != '\0'; i++) {
    nbHache += chaine[i];
  }
  nbHache %= 100;
  return nbHache;
}



/**
 * @brief Adds a new key-value pair to the HashMap.
 *
 * This function adds a new key-value pair to the HashMap.
 * It uses an addTree function corresponding to this hash index.
 * If the addition is successful (addTree returns 1), it increments the size of
 * the HashMap and returns 1. Otherwise it returns 0.
 *
 * @param hashmap A pointer to the HashMap.
 * @param key The key to add.
 * @param value The value to associate with the key.
 * @return 1 if the addition is successful, 0 otherwise.
 */

int addHM(HM *map, char *key, int value) {
  int hash = hachage(key);
  int result = addArbre(&(map->pRoot), key, hash, value);
  if (result == 1) {
    map->size++;
  }
  return result;
}



/**
 * @brief Retrieves the value associated with a given key in the HashMap.
 *
 * This function retrieves the value associated with a given key in the
 * HashMap. It uses a searchTree function to search for the value in the
 * corresponding tree. If the search is successful, it returns a pointer to the
 * value found. Otherwise, it frees the memory allocated for the result and returns
 * NULL.
 *
 * @param hashmap A pointer to the HashMap.
 * @param key The key to search for.
 * @return A pointer to the value if found, NULL otherwise.
 */

int *getHM(HM *map, char *key) {
  if(map != NULL || key != NULL){
  int *result = NULL;
  int hash = hachage(key);
  if (searchTree(map->pRoot, key, hash, &result)) {
    return result;
  } else {
    free(result);
    return NULL;
  }
  }
}


/**
 * @brief Removes a key-value pair from the HashMap.
 *
 * This function removes a key-value pair from the HashMap.
 * It uses a removeTree function to remove the key-value pair from the tree
 * corresponding to this hash index. It returns the result of the remove
 * operation and size-1.
 *
 * @param hashmap A pointer to the HashMap.
 * @param key The key to remove.
 * @return The result of the remove operation and size-1.
 */

int removeHM(HM *map, char *key) {
  if(map != NULL || key != NULL){
  int hash = hachage(key);
  int result = removeTree(&(map->pRoot), key, hash);
  if (result == 1) {
    map->size--;
  }
  return result;
  }
}


/**
 * @brief Returns the current size of the HashMap.
 *
 * This function returns the current size of the HashMap.
 *
 * @param hashmap A pointer to the HashMap.
 * @return The current size of the HashMap.
 */

int sizeHM(HM *map) { 
  if(map != NULL){
    return map->size; 
  }else{
    return 0;
  }
}


/**
 * @brief Updates the value associated with a given key in the HashMap.
 *
 * This function updates the value associated with a given key in the HashMap.
 * It searches for the element in the tree corresponding to this hash index and
 * updates the value if the key is found. It returns true if the update succeeds,
 * otherwise false.
 *
 * @param hashmap A pointer to the HashMap.
 * @param key The key to update.
 * @param value The new value to associate with the key.
 * @return true if the update succeeds, false otherwise.
 */

int updateHM(HM *map, char *key, int newValue) {
  int hash = hachage(key);
  Tree *current = map->pRoot;

  // Search for the item to be updated
  while (current != NULL) {
    if (current->hash == hash) {
      Node *currentNode = current->cell;
      while (currentNode != NULL) {
        if (strcmp(currentNode->key, key) == 0) {
          // The key has been found, update the value
          currentNode->value = newValue;
          return 1; // Update success
        }
        currentNode = currentNode->pNext;
      }
    }

    // Mise à jour du pointeur pour la recherche dans l'arbre
    if (current->hash < hash) {
      current = current->pright;
    } else {
      current = current->pleft;
    }
  }

  // Updating the pointer for tree searches
  return 0;
}


/**
 * @brief Displays the contents of the HashMap.
 *
 * This function displays the contents of the HashMap by prefixing through the
 * tree and displaying each key-value pair.
 *
 * @param hashmap A pointer to the HashMap.
 */

void display(HM *map) {
  if(map != NULL){
  parcoursPrefixe(map->pRoot);
  }else{
    printf("Map nul");
  }
}


/**
 * @brief Frees the memory allocated for the HashMap.
 *
 * This function frees the memory allocated for the HashMap by using a freeTree
 * function to free the memory for each node in the tree.
 *
 * @param hashmap A pointer to the HashMap.
 */
 
void freeHashMap(HM *map) {
  freeTree(map->pRoot);
  free(map);
}

