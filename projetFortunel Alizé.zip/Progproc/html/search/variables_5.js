var searchData=
[
  ['value_75',['value',['../structNode.html#aaa0cd30d78a90c5a6ab64eb3d58b8f87',1,'Node']]]
];
