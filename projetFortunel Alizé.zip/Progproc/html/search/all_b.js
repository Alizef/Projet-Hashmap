var searchData=
[
  ['removehm_29',['removeHM',['../hashmap_8c.html#a6e6be2aa643af6b94132ed7962410e34',1,'removeHM(HM *map, char *key):&#160;hashmap.c'],['../hashmap_8h.html#a6e6be2aa643af6b94132ed7962410e34',1,'removeHM(HM *map, char *key):&#160;hashmap.c']]],
  ['removetree_30',['removeTree',['../abr_8c.html#a574e08501a1d3f3caa39ff37225ed4e2',1,'removeTree(Tree **head, char *key, int hash):&#160;abr.c'],['../abr_8h.html#a574e08501a1d3f3caa39ff37225ed4e2',1,'removeTree(Tree **head, char *key, int hash):&#160;abr.c']]]
];
