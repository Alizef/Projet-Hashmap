var searchData=
[
  ['freehashmap_55',['freeHashMap',['../hashmap_8c.html#a938cf4e767a44a2e2cc18a01c848ed22',1,'freeHashMap(HM *map):&#160;hashmap.c'],['../hashmap_8h.html#a938cf4e767a44a2e2cc18a01c848ed22',1,'freeHashMap(HM *map):&#160;hashmap.c']]],
  ['freetree_56',['freeTree',['../abr_8c.html#ae41207d44770ec8dd1284592da4761b7',1,'freeTree(Tree *node):&#160;abr.c'],['../abr_8h.html#ae41207d44770ec8dd1284592da4761b7',1,'freeTree(Tree *node):&#160;abr.c']]]
];
