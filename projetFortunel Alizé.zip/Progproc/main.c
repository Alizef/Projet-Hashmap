#include "abr.h"
#include "hashmap.h"
#include "listechaine.h"
#include <stdio.h>

int main() {
  HM *map = createHashMap();

  // Add key-value pairs
  addHM(map, "sss", 42);
  addHM(map, "rueil", 73);
  addHM(map, "merlin", 99);
  addHM(map, "yuyu", 27);
  addHM(map, "cerise", 38);
  addHM(map, "lilou", 13);

  // Display the initial state of the hash map
  printf("Initial HashMap: \n\n");
  display(map);
  printf("_______________\n\n");

  printf("Size of the HashMap: %d\n", sizeHM(map));
  printf("_______________\n\n");

  // Get and print the value associated with "key1"
  int *result = getHM(map, "sss");
  if (result != NULL) {
    printf("Value for sss: %d\n", *result);
  } else {
    printf("sss not found in the HashMap\n");
  }
  printf("_______________\n\n");


  // Remove "yuyu" from the hash map
  // Display the updated state of the hash map
  removeHM(map, "yuyu");
  printf("HashMap after removing yuyu:\n");
  display(map);
  printf("_______________\n\n");

  // Update the value for "key1"


  // Display the final state of the hash map
  printf("Final Hashmap:\n");
  if(updateHM(map, "rueil",55) ==1){
    updateHM(map, "rueil", 55);
  }
  if(updateHM(map, "cerise",38) ==1){
    updateHM(map, "cerise", 49);
  }
  display(map);
  printf("_______________\n\n");

  // Print the size of the hash map
  printf("Size of the HashMap: %d\n", sizeHM(map));
  printf("\n");

  // Free the memory used by the hash map
  freeHashMap(map);

  return 0;
}