#ifndef LISTECHAINE_H
#define LISTECHAINE_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "abr.h"


/**
 * @brief Structure representing a node in a linked list.
 *
 * This structure represents a node in a linked list used in the hashmap.
 */

typedef struct Node {
  char *key;
  int value;
  struct Node *pNext;
} Node;


Node *createChainon(char *K, int V);
void afficherListeRec(Node *chainon);

#endif
