#include "listechaine.h"

/**
 * @brief Creates a new linked list node.
 *
 * This function creates a new Node node. It takes a key K and a
 * value V as parameters, and dynamically allocates memory for the node. It copies
 * the key into the node, initializes its value, and initializes the next pointer
 * pNext to NULL. If memory allocation fails, the program terminates with error
 * code 1.
 *
 * @param key The key to be associated with the node.
 * @param value The value to be associated with the key.
 * @return A pointer to the new linked list node.
 */

Node *createChainon(char *K, int V) {
  if (K == NULL) {
    printf("Error: Key is NULL\n");
    exit(1);
  }

  Node *n = malloc(sizeof(Node));
  if (n == NULL) {
    printf("Memory allocation failed for Node\n");
    exit(1);
  }

  // Allocates memory for the key and copies the key
  n->key = strdup(K);
  if (n->key == NULL) {
    printf("Memory allocation failed for key\n");
    exit(1);
  }

  n->value = V;
  n->pNext = NULL;

  return n;
}



/**
 * @brief Recursively displays the elements of a linked list.
 *
 * This function recursively displays the elements of a linked list
 * starting from the node passed as the chainon parameter. It displays the key and
 * value of each node, then recursively calls the function for the next node. If
 * the node is NULL, the program ends with error code 3.
 *
 * @param chainon The starting node of the linked list.
 */

void afficherListeRec(Node *chainon) {
  if (chainon != NULL) {
    printf("%s - %d ; -> ", chainon->key, chainon->value);
    afficherListeRec(chainon->pNext);
  } else {
    // Handle the case where chainon is NULL (optional)
    printf("\n");
  }
}

