#ifndef ABR_H
#define ABR_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "listechaine.h"

/**
 * @brief Structure representing a tree node.
 *
 * This structure represents a tree node in the hashmap.
 */


typedef struct Tree {
  int hash;
  struct Tree *pleft;
  struct Tree *pright;
  struct Node *cell;
} Tree;

Tree *createTree(int a, char *k, int v);
int addArbre(Tree **head, char *key, int hash, int value);
int searchTree(Tree *head, char *key, int hash, int **result);
Tree *suppMax(Tree *node, Tree *pTarget);
int removeTree(Tree **head, char *key, int hash);
void parcoursPrefixe(Tree *arb);
void freeTree(Tree *node);

#endif
